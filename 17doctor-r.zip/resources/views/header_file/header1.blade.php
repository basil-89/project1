<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>|| Doctors</title>

    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="{{asset('assets/img/favicon.ico')}}"  />
    <!--====== Animate Css ======-->
     <link rel="stylesheet" href="{{asset('assets/css/animate.min.css')}}" />
    <!--====== Bootstrap css ======-->
    <link rel="stylesheet" href="{{asset('assets/css/bootstrap.min.css')}}" />
    <!--====== Slick Slider ======-->
    <link rel="stylesheet" href="{{asset('assets/css/slick.min.css')}}" />
    <!--====== Nice Select ======-->
    <link rel="stylesheet" href="{{asset('assets/css/nice-select.min.css')}}" />
    <!--====== Magnific Popup ======-->
    <link rel="stylesheet" href="{{asset('assets/css/magnific-popup.min.css')}}" />
    <!--====== Font Awesome ======-->
     <link rel="stylesheet" href="{{asset('assets/fonts/fontawesome/css/all.min.css')}}" />
    <!--====== Flaticon ======-->
     <link rel="stylesheet" href="{{asset('assets/fonts/flaticon/css/flaticon.css')}}" /> 
    <!--====== Main Css ======-->
    <link rel="stylesheet" href="{{asset('/assets/css/style.css')}}"  />

</head>

